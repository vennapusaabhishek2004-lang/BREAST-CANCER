import pandas as pd
import pickle
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score

# 1. Path Setting (Relative Path is better for projects)
# Unga folder-kulla 'data' folder irundha idhaiye use pannunga
DATA_PATH = "data/data.csv" 
MODEL_DIR = 'models'

if not os.path.exists(MODEL_DIR):
    os.makedirs(MODEL_DIR)

# 2. Load Data
df = pd.read_csv(DATA_PATH)
df = df.drop(['id', 'Unnamed: 32'], axis=1, errors='ignore')
df['diagnosis'] = df['diagnosis'].map({'M': 1, 'B': 0})

X = df.drop('diagnosis', axis=1)
y = df['diagnosis']

# 3. Split & Scale
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 4. Define Base Models
m1 = XGBClassifier()
m2 = RandomForestClassifier(n_estimators=100)
m3 = SVC(probability=True)

# 5. Adaptive Logic: Calculate Accuracy to use as weights
m1.fit(X_train_scaled, y_train)
m2.fit(X_train_scaled, y_train)
m3.fit(X_train_scaled, y_train)

# Ivanga Predict panni accuracy kandupidippom
w1 = accuracy_score(y_test, m1.predict(X_test_scaled))
w2 = accuracy_score(y_test, m2.predict(X_test_scaled))
w3 = accuracy_score(y_test, m3.predict(X_test_scaled))

# 6. Adaptive Ensemble (Weights assigned based on performance)
ensemble = VotingClassifier(
    estimators=[('xgb', m1), ('rf', m2), ('svc', m3)], 
    voting='soft',
    weights=[w1, w2, w3] # Ithu thaan "Adaptive" part
)
ensemble.fit(X_train_scaled, y_train)

# 7. Save to models folder
pickle.dump(ensemble, open(f'{MODEL_DIR}/cancer_model.pkl', 'wb'))
pickle.dump(scaler, open(f'{MODEL_DIR}/scaler.pkl', 'wb'))

print(f"✅ Adaptive Model Saved! Weights: XGB={w1:.2f}, RF={w2:.2f}, SVM={w3:.2f}")