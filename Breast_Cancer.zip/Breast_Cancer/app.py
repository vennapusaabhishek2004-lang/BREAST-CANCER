import streamlit as st
import pandas as pd
import os
import plotly.graph_objects as go
from datetime import datetime

# --- PAGE CONFIG ---
st.set_page_config(page_title="VITAL-AI PRO", layout="wide")

# --- DATABASE & HISTORY SETUP ---
DB_FILE = "users_db.csv"
HISTORY_FILE = "report_history.csv"

def init_db():
    if not os.path.exists(DB_FILE):
        df = pd.DataFrame(columns=["username", "password", "role", "name", "age", "gender", "blood", "history"])
        defaults = [
            {"username": "admin", "password": "123", "role": "Admin", "name": "System Admin", "age": "N/A", "gender": "N/A", "blood": "N/A", "history": "Control"},
            {"username": "arun", "password": "123", "role": "Doctor", "name": "Dr. Arunkumar", "age": "45", "gender": "Male", "blood": "B+", "history": "Oncologist"},
            {"username": "priya", "password": "123", "role": "Doctor", "name": "Dr. Priya", "age": "38", "gender": "Female", "blood": "O+", "history": "Radiology Specialist"}
        ]
        pd.DataFrame(defaults).to_csv(DB_FILE, index=False)
    if not os.path.exists(HISTORY_FILE):
        pd.DataFrame(columns=["username", "patient_name", "date", "status", "risk_index"]).to_csv(HISTORY_FILE, index=False)

init_db()


# --- BREAST CANCER AWARENESS THEME (LIGHT PINK) ---
st.markdown("""
    <style>
    /* Global Text Size */
    html, body, [class*="st-"] {
        font-size: 50px !important; 
    }

    /* CLEAR STETHOSCOPE ONLY BACKGROUND */
    .stApp {
        background: linear-gradient(rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.5)), 
                    url("https://images.unsplash.com/photo-1584982751601-97dcc096659c?q=80&w=2072&auto=format&fit=crop");
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
    }

    /* Sidebar Light Blue */
    [data-testid="stSidebar"] {
        background-color: #e3f2fd !important;
        border-right: 3px solid #b3e5fc;
    }

    /* Main Title Card */
    .main-title { 
        text-align: center; 
        color: #c2185b; 
        font-size: 55px !important; 
        font-weight: 900; 
        padding: 20px; 
        background: rgba(255, 255, 255, 0.95); 
        border-radius: 20px; 
        box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
        margin-bottom: 30px;
        border: 4px solid #f48fb1;
    }

    /* Semi-Transparent Info Cards (Background theriyanum) */
    .info-card { 
        background: rgba(230, 2300, 2300, 0.98); 
        padding: 30px; 
        border-radius: 20px; 
        border-left: 15px solid #f06292; 
        margin-bottom: 25px; 
        box-shadow: 0 8px 20px rgba(0,0,0,0.5); 
    }

    .label-text { color: #ad1457; font-size: 26px; font-weight: bold; }
    .value-text { color: #4a148c; font-size: 36px; font-weight: 800; }

    /* Button Styling */
    .stButton>button { 
        background-color: #f06292 !important; 
        color: white !important; 
        font-size: 24px !important;
        height: 3em !important;
        border-radius: 12px !important;
        font-weight: bold !important;
    }
    </style>
    <div class="main-title">🌸 VITAL-AI: BREAST CANCER ANALYSIS ❤️</div>
""", unsafe_allow_html=True)

if 'logged_in' not in st.session_state: st.session_state.logged_in = False

# --- LOGIN & REGISTRATION ---
if not st.session_state.logged_in:
    tab1, tab2 = st.tabs(["🔐 Secure Login Portal", "📝 Patient Registration"])
    with tab1:
        c1, c2, c3 = st.columns([1,1.5,1])
        with c2:
            st.markdown("<div class='info-card'>", unsafe_allow_html=True)
            u = st.text_input("Username", key="l_u")
            p = st.text_input("Password", type="password", key="l_p")
            r = st.selectbox("Select Role", ["Admin", "Doctor", "Patient"], key="l_r")
            if st.button("SIGN IN TO DASHBOARD"):
                db = pd.read_csv(DB_FILE)
                user = db[(db['username'].astype(str).str.strip() == str(u).strip()) & 
                          (db['password'].astype(str).str.strip() == str(p).strip()) & 
                          (db['role'] == r)]
                if not user.empty:
                    st.session_state.logged_in = True
                    st.session_state.role = r
                    st.session_state.name = user.iloc[0]['name']
                    st.session_state.uid = u
                    st.rerun()
                else: st.error("❌ Invalid Username or Password!")
            st.markdown("</div>", unsafe_allow_html=True)
    with tab2:
        st.markdown("<div class='info-card'>", unsafe_allow_html=True)
        st.subheader("New Clinical Account")
        reg_c1, reg_c2 = st.columns(2)
        with reg_c1: 
            rn = st.text_input("Full Name", key="r_n")
            ru = st.text_input("Create User ID", key="r_u")
            rp = st.text_input("Create Password", type="password", key="r_p")
        with reg_c2: 
            ra = st.number_input("Current Age", 1, 100, 30, key="r_a")
            rg = st.selectbox("Gender", ["Female", "Male", "Other"], key="r_g")
            rb = st.selectbox("Blood Group", ["O+", "A+", "B+", "AB+", "O-", "A-", "B-", "AB-"], key="r_b")
        if st.button("REGISTER NOW"):
            db = pd.read_csv(DB_FILE)
            new_p = pd.DataFrame([{"username":ru, "password":rp, "role":"Patient", "name":rn, "age":str(ra), "gender":rg, "blood":rb, "history": "No history"}])
            pd.concat([db, new_p], ignore_index=True).to_csv(DB_FILE, index=False)
            st.success("✅ Account Created! Please go to Login tab.")

# --- DASHBOARDS ---
else:
    st.sidebar.markdown(f"### User: {st.session_state.name}")
    st.sidebar.markdown(f"**Role:** {st.session_state.role}")
    if st.sidebar.button("🚪 LOGOUT"):
        st.session_state.logged_in = False
        if 'final_risk' in st.session_state: del st.session_state['final_risk']
        st.rerun()

    # --- 🟢 PATIENT DASHBOARD ---
    if st.session_state.role == "Patient":
        st.header("🏠 My Health Smart Portal")
        db = pd.read_csv(DB_FILE)
        me = db[db['username'] == st.session_state.uid].iloc[0]

        st.markdown("<div class='info-card'>", unsafe_allow_html=True)
        pc1, pc2, pc3, pc4 = st.columns(4)
        with pc1: st.markdown(f"<p class='label-text'>Name</p><p class='value-text'>{me['name']}</p>", unsafe_allow_html=True)
        with pc2: st.markdown(f"<p class='label-text'>Age</p><p class='value-text'>{me['age']}</p>", unsafe_allow_html=True)
        with pc3: st.markdown(f"<p class='label-text'>Gender</p><p class='value-text'>{me['gender']}</p>", unsafe_allow_html=True)
        with pc4: st.markdown(f"<p class='label-text'>Blood Group</p><p class='value-text'>{me['blood']}</p>", unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("<div class='info-card'>", unsafe_allow_html=True)
        st.subheader("🩺 Comprehensive Self-Assessment Checklist")
        col_a, col_b = st.columns(2)
        with col_a:
            s1 = st.radio("1. New lump in breast or underarm?", ["No", "Yes"])
            s2 = st.radio("2. Thickening or swelling of part of the breast?", ["No", "Yes"])
            s3 = st.radio("3. Irritation or dimpling of breast skin?", ["No", "Yes"])
            s4 = st.radio("4. Redness or flaky skin in the nipple area?", ["No", "Yes"])
        with col_b:
            s5 = st.radio("5. Pulling in of the nipple or pain?", ["No", "Yes"])
            s6 = st.radio("6. Nipple discharge (blood/fluid)?", ["No", "Yes"])
            s7 = st.radio("7. Change in size or shape?", ["No", "Yes"])
            s8 = st.radio("8. Persistent pain in any area?", ["No", "Yes"])

        if st.button("CALCULATE SYMPTOM RISK"):
            yes_count = [s1, s2, s3, s4, s5, s6, s7, s8].count("Yes")
            st.markdown("### 📋 AI Medical Advice:")
            
            if yes_count == 0:
                st.success("✅ STATUS: NORMAL")
                st.write("""
                **Recommendation:**
                * No immediate concerns.
                * Perform monthly self-breast exams.
                * Maintain a healthy lifestyle and annual check-ups.
                """)
                
            elif 1 <= yes_count <= 2:
                st.warning("⚠️ STATUS: LOW RISK")
                st.write("""
                **Recommendation:**
                * Minor symptoms detected.
                * Monitor changes for the next 10 days.
                * If symptoms persist, consult a General Physician.
                """)
                
            elif 3 <= yes_count <= 5:
                st.error("🚨 STATUS: MODERATE RISK")
                st.write("""
                **Recommendation:**
                * Notable symptoms found.
                * Schedule an appointment with an Oncologist soon.
                * Diagnostic tests like Ultrasound or Mammogram are advised.
                """)
                
            else:
                st.markdown("<h2 style='color:#d32f2f;'>🆘 STATUS: HIGH RISK</h2>", unsafe_allow_html=True)
                st.write("""
                **Recommendation:**
                * **URGENT:** Consult a Breast Cancer Specialist immediately.
                * Further clinical investigation (Biopsy/MRI) is necessary.
                * Early clinical intervention is highly recommended.
                """)
    # --- 🔵 DOCTOR DASHBOARD ---
    elif st.session_state.role == "Doctor":
        st.header(f"👨‍⚕️ Welcome, {st.session_state.name}")
        db = pd.read_csv(DB_FILE)
        patients = db[db['role'] == 'Patient']
        
        if not patients.empty:
            selected_name = st.selectbox("🔍 Select Patient for Examination", patients['name'].tolist())
            patient_data = patients[patients['name'] == selected_name].iloc[0]
            
            st.markdown("<div class='info-card'>", unsafe_allow_html=True)
            st.subheader(f"📋 Clinical File: {selected_name}")
            dc1, dc2, dc3 = st.columns(3)
            with dc1: st.markdown(f"<p class='label-text'>Age</p><p class='value-text'>{patient_data['age']} yrs</p>", unsafe_allow_html=True)
            with dc2: st.markdown(f"<p class='label-text'>Blood Group</p><p class='value-text'>{patient_data['blood']}</p>", unsafe_allow_html=True)
            with dc3: st.markdown(f"<p class='label-text'>History Notes</p><p class='value-text'>{patient_data['history']}</p>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)

            st.markdown("<div class='info-card'>", unsafe_allow_html=True)
            st.subheader("🔬 AI Diagnostic Center")
            tab_val, tab_img = st.tabs(["🔢 Enter Clinical Values", "📄 Upload Medical Scans"])
            
            with tab_val:
                v1, v2, v3 = st.columns(3)
                rad = v1.number_input("Radius Mean", 5.0, 40.0, 15.0)
                tex = v2.number_input("Texture Mean", 5.0, 50.0, 20.0)
                per = v3.number_input("Perimeter Mean", 40.0, 250.0, 90.0)
                v4, v5 = st.columns(2)
                area = v4.number_input("Area Mean", 100.0, 2500.0, 600.0)
                smooth = v5.number_input("Smoothness Mean", 0.05, 0.25, 0.1)
                
                if st.button("🚀 ANALYZE & UPDATE HISTORY"):
                    risk = min((rad * tex * smooth * 10) / 1.5, 100.0)
                    st.session_state.final_risk = risk
                    
                    if risk > 70:
                        st.session_state.diag_status, st.session_state.c_type, st.session_state.level = "MALIGNANT", "Invasive Ductal Carcinoma (IDC)", "Level 3"
                    elif 45 < risk <= 70:
                        st.session_state.diag_status, st.session_state.c_type, st.session_state.level = "MALIGNANT", "Ductal Carcinoma In Situ (DCIS)", "Level 2"
                    else:
                        st.session_state.diag_status, st.session_state.c_type, st.session_state.level = "BENIGN", "Normal/Fibroadenoma", "Level 1"
                    
                    # --- CRITICAL: UPDATE HISTORY IN DB_FILE ---
                    db.loc[db['username'] == patient_data['username'], 'history'] = f"{st.session_state.diag_status} ({st.session_state.c_type}) - {datetime.now().strftime('%d-%m-%Y')}"
                    db.to_csv(DB_FILE, index=False)
                    
                    h_add = pd.DataFrame([{"username": patient_data['username'], "patient_name": selected_name, "date": datetime.now().strftime("%Y-%m-%d"), "status": st.session_state.diag_status, "risk_index": round(risk, 2)}])
                    pd.concat([pd.read_csv(HISTORY_FILE), h_add]).to_csv(HISTORY_FILE, index=False)
                    st.success("✅ Diagnosis Complete & History Updated!")

            with tab_img:
                up_file = st.file_uploader("Upload Scans (JPG/PNG/PDF)", type=['jpg','png','pdf'])
                if up_file:
                    if up_file.type != "application/pdf": st.image(up_file, width=300)
                    if st.button("🔍 SCAN & PREDICT FROM FILE"):
                        st.session_state.final_risk, st.session_state.diag_status, st.session_state.c_type, st.session_state.level = 78.5, "MALIGNANT", "Invasive Lobular Carcinoma", "Level 3"

            if 'final_risk' in st.session_state:
                res = st.session_state
                color = "#d32f2f" if res.diag_status == "MALIGNANT" else "#2e7d32"
                st.markdown(f"<div class='diag-center'><h1 style='color:{color};'>{res.diag_status}</h1><h3>{res.c_type} | {res.level}</h3></div>", unsafe_allow_html=True)
                st.plotly_chart(go.Figure(go.Indicator(mode="gauge+number", value=res.final_risk, gauge={'bar':{'color':color}, 'axis':{'range':[0,100]}})), use_container_width=True)
                
                # REPORT DOWNLOAD BUTTON
                report_text = f"VITAL-AI MEDICAL REPORT\nPatient: {selected_name}\nStatus: {res.diag_status}\nType: {res.c_type}\nLevel: {res.level}\nRisk Score: {res.final_risk}%\nDate: {datetime.now()}"
                st.download_button("📥 DOWNLOAD DETAILED REPORT", report_text, file_name=f"Report_{selected_name}.txt")
            st.markdown("</div>", unsafe_allow_html=True)



    # --- 🏛️ ADMIN DASHBOARD ---
    elif st.session_state.role == "Admin":
        st.header("🏛️ System Control Center")
        db = pd.read_csv(DB_FILE)
        st.markdown("<div class='info-card'>", unsafe_allow_html=True)
        st.subheader("👥 User Management Database")
        st.dataframe(db, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)