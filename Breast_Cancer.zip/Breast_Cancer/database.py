import pandas as pd
import os

DB_FILE = "users_db.csv"

def init_db():
   
    if not os.path.exists(DB_FILE):
        df = pd.DataFrame([
            {"username": "admin", "password": "123", "role": "Admin", "name": "System Admin"},
            {"username": "doctor", "password": "123", "role": "Doctor", "name": "Dr. Arunkumar"},
            {"username": "priya", "password": "123", "role": "Doctor", "name": "Dr. Priya"}
        ])
        df.to_csv(DB_FILE, index=False)

def load_db():
    if os.path.exists(DB_FILE):
        return pd.read_csv(DB_FILE)
    return pd.DataFrame()

def add_user(name, username, password, role="Patient"):
    db = load_db()
  
    new_user = pd.DataFrame([{"username": username, "password": str(password), "role": role, "name": name}])
    updated_db = pd.concat([db, new_user], ignore_index=True)
    updated_db.to_csv(DB_FILE, index=False)