import streamlit as st

def apply_custom_design():
    st.markdown("""
        <style>
        .stApp { background-color: #f4f7f9; }
        .main-card { 
            background: white; padding: 25px; border-radius: 15px; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.1); 
            border-top: 6px solid #007bff; margin-bottom: 20px; 
        }
        h1, h2 { color: #1e3a8a; text-align: center; }
        .stButton>button { width: 100%; border-radius: 8px; font-weight: bold; }
        </style>
    """, unsafe_allow_html=True)