import pickle
import plotly.graph_objects as go
import streamlit as st

def get_prediction(r, t, p, a):
    try:
        model = pickle.load(open('models/cancer_model.pkl', 'rb'))
        scaler = pickle.load(open('models/scaler.pkl', 'rb'))
        
        data = [0]*30
        data[0:4] = [r, t, p, a]
        scaled = scaler.transform([data])
        
        prediction = model.predict(scaled)[0]
        prob = model.predict_proba(scaled)[0][1] * 100
        
        return prediction, prob
    except:
        return None, None

def show_gauge(prob, color):
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=prob,
        gauge={'axis': {'range': [0, 100]}, 'bar': {'color': color}}
    ))
    st.plotly_chart(fig)